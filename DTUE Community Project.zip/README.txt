IWAD: Doom2.wad

Midi in the (dedicated) deathmatch map made by: Dermoker

Maps created by:

Epsilon (LagZero) - Bootleg Crossfire (Deathmatch)
Barox395 - Nukage Storage
Momentbitter - M88
TheV1perK1ller - Hazard Reduction
NeedsF00DBadly - Warp Gate
AlexEightch - Lockdown
TheMightyWhoosh - Sperimentare
Bubba2181 - Delta Complex

Thanks to Barox395 for the custom map names.